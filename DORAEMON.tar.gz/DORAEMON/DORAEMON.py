# DORAEMON: conDitiOnal pRobabilistic Approach for idEntification of aMino acids interacting with ribONucleic acids #
# Annotate Biomolecules Computationally Group, 2016 #


import sys, os, numpy as np, math

# Conditional probability matrix
priorN=0.5
priorP=0.5

posMatf=open('posMat.txt','r')
allPosMat=posMatf.read().split('\n')[:-1]
posMatf.close()
#print allPosMat

negMatf=open('negMat.txt','r')
allNegMat=negMatf.read().split('\n')[:-1]
negMatf.close()
#print allNegMat


# Flanking region (win) on either side
win=5


# Naturally occurring amino acids      
AA=['A','C','D','E','F','G','H','I','K','L','M','N','P','Q','R','S','T','V','W','Y']

# Check name
try:
    prot_file = sys.argv[1]
except IndexError:
    sys.exit('Usage: $python DORAEMON.py <input .fa file>')

tname=prot_file.split('.')[0]
for t in tname:
    if t in "~`!@#$%^&*()-+={}[]:>;',</?*-+":
        sys.exit('Invalid name! (Use A-Z a-z 0-9 and _ )')

# Sequence
SEQ=''
seqf = open(tname+'.fa','r')
v2 = seqf.read().split('\n')[:-1]
for line in v2:
  if line.count('>')== 0 and line.count('_')==0:
    SEQ=SEQ+line.rstrip()
seqf.close()


print 'Running preliminary check..............'

# Check input residue types
nonNO_AA = ''
for i1 in SEQ:
    if i1 not in AA:
        nonNO_AA = nonNO_AA+i1
if len(nonNO_AA) != 0:
    print 'Error Type: Given input has non-naturally occurring amino acids.',
    print 'Check file and retry.'

if (len(nonNO_AA) == 0) and (len(SEQ) > 10):
    # Preliminary check done
    print 'Preliminary check successful.'
    
    print 'Estimating the probabilities for discrimination..............'
    # output file
    outF = open(tname+'_DORAEMON.txt','w')
    outF.write('# DORAEMON RESULTS for '+tname+' at 5.0 Angstorm Distance cut-off #\n')
    outF.write('# Annotate Biomolecules Computationally group, 2016 #\n')
    outF.write('\n')
    


    outF.write('Interpretation:\n')
    outF.write('Column 1: Serial number/position\n')
    outF.write('Column 2: Probability score (interacting) \n')
    outF.write('Column 3: Probability score (non-interacting) \n')
    outF.write('Column 4: Prediction (1: interacting; -1: non-interacting) \n')
    outF.write('============================== START =============================\n')
    s=0
    while s < len(SEQ):
      if (s >= int(win)) and (s < len(SEQ)-int(win)):
        fragSEQ=SEQ[s - int(win):(s + int(win) + 1)]
      
        # Probability estimation and comparison
        p=0
        Pscore=1.0
        while p < len(fragSEQ):
          Pscore = Pscore * float(allPosMat[p].split()[AA.index(fragSEQ[p])])*priorP
          p=p+1

        n=0
        Nscore=1.0
        while n < len(fragSEQ):
          Nscore = Nscore * float(allNegMat[n].split()[AA.index(fragSEQ[n])])*priorN
          n=n+1

        if Pscore > Nscore:
          predClass=1
        elif Pscore < Nscore:
          predClass=-1
        elif Pscore == Nscore:
          predClass=0 
        

        outF.write(str(s+1)+'\t'+SEQ[s]+'\t'+str(Pscore)+'\t'+str(Nscore)+'\t'+str(predClass)+'\n')

      s=s+1
    outF.write('# ========================== END =============================== #')

    print 'Prediction completed successfully'
    outF.close()
